#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void cargarCadena(char *palabra, int tamano);

#endif // FUNCIONES_H_INCLUDED
