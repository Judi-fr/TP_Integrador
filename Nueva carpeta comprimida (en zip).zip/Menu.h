#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "1_clsSuscripcion.h"
#include "3_clsCancion.h"

///MENUS///////////////////////////////
void Menu1();
void Menu2();
void MenuAdmin();
void MenuReportes();

///SWITCHS/////////////////////////////
Suscripcion switch1(Suscripcion );
Suscripcion switch2(Suscripcion ,Fecha );
Suscripcion switchAdm(Suscripcion );


#endif // MENU_H_INCLUDED
