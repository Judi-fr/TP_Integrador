#ifndef MENULISTARCANCIONES_H_INCLUDED
#define MENULISTARCANCIONES_H_INCLUDED

///LISTA-CANCIONES/////////////////////
void menu_canciones();
Cancion interaccion_de_menu();
void dibujar_cajas(int ,int );
void pintarCaja(int , int );
void dibujar_canciones(int ,int ,Cancion );


#endif // MENULISTARCANCIONES_H_INCLUDED
